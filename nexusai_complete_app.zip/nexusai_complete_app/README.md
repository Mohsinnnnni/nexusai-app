# NexusAI Complete Upgrade Pack

هذه حزمة تنفيذ جاهزة لتوسعة مشروعك الحالي ليصبح:
- منصة محادثة متعددة النماذج
- دعم مفاتيح API لكل نموذج
- تحديث تلقائي للنماذج من OpenRouter
- قسم بحوث إسلامية
- AI Developer + App Builder + APK Builder
- Smart AI Brain + Smart Router
- تحسين رفع الملفات والـ streaming
- Build server لتحويل المواقع والمشاريع إلى APK

## الملفات الأساسية
- `src/lib/stream-chat.ts` نسخة محسنة
- `supabase/functions/chat/index.ts` نسخة محسنة
- `src/model-registry.ts`
- `src/model-updater.ts`
- `src/ai-brain.ts`
- `src/ai-router.ts`
- `src/pages/IslamicResearch.tsx`
- `src/pages/AIDeveloper.tsx`
- `src/pages/AppBuilder.tsx`
- `src/pages/APKBuilder.tsx`
- `src/data/hadith-db.sample.json`
- `server/build.js`
- `server/runtime/code-runner.js`
- `server/runtime/zip-runner.js`

## ملاحظات مهمة
1. هذه الحزمة مبنية على المعطيات التي أرسلتها أنت: `package.json` + `stream-chat.ts` + `supabase/functions/chat/index.ts` + صور الواجهة.
2. لأن كامل المستودع غير متاح هنا، هذه الحزمة هي **نسخة دمج جاهزة** وليست نسخة مطابقة 100% لبنية ملفات مشروعك الحالية.
3. ابدأ باستبدال ملفي الشات والـ edge function، ثم أضف الملفات الجديدة، ثم اربط الصفحات في الراوتر والقائمة الجانبية.
4. إذا أردت إخراج APK، استخدم `Capacitor` كما هو موضح في الأسفل.

## أوامر التشغيل
```bash
npm install
npm run build
```

## أوامر Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/filesystem @capacitor/share @capacitor/camera @capacitor/splash-screen
npx cap init nexusai com.nexusai.app
npx cap add android
npx cap copy
npx cap open android
```

## Build server
```bash
cd server
npm install express unzipper
node build.js
```

## أسرار البيئة المطلوبة
### Frontend
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

### Supabase Edge Function
- `LOVABLE_API_KEY`
- `OPENROUTER_API_KEY`
- `OPENAI_API_KEY`
- `GROQ_API_KEY`
- `PERPLEXITY_API_KEY`

يمكنك أيضًا تعريف مفاتيح خاصة بالنماذج مثل:
- `MODEL_KEY_OPENROUTER_OPENAI_GPT_5`
- `MODEL_KEY_OPENROUTER_DEEPSEEK_DEEPSEEK_CHAT`
- `MODEL_KEY_OPENROUTER_MOONSHOTAI_KIMI_K2`

## دمج الصفحات
أضف الصفحات التالية إلى الراوتر:
- `/islamic-research`
- `/ai-developer`
- `/app-builder`
- `/apk-builder`

وأضفها إلى القائمة الجانبية بعناوين:
- البحوث الإسلامية
- AI Developer
- AI App Builder
- APK Builder
