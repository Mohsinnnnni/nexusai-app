export function chooseBestModel(prompt: string, hasFiles = false): string {
  const text = prompt.toLowerCase();

  if (/\b(code|bug|debug|refactor|typescript|react|node|python|flutter)\b/.test(text) || /برمج|كود|اصلاح|موقع|تطبيق/.test(text)) {
    return "openrouter/anthropic/claude-3.5-sonnet";
  }

  if (/\b(image|draw|picture|logo|banner)\b/.test(text) || /صورة|ارسم|شعار/.test(text)) {
    return "openrouter/google/gemini-2.5-flash-image";
  }

  if (/\b(news|search|research|latest)\b/.test(text) || /بحث|اخر|أحدث/.test(text)) {
    return "perplexity/sonar";
  }

  if (hasFiles) {
    return "openrouter/google/gemini-2.5-flash";
  }

  return "openrouter/openai/gpt-5";
}
