export function buildProjectPrompt(prompt: string) {
  return `
أنشئ مشروعاً كاملاً بناءً على هذا الوصف:
${prompt}

أخرج النتيجة على شكل ملفات منفصلة.
إذا كان المطلوب موقعاً استخدم React + Tailwind.
إذا كان المطلوب تطبيق Android استخدم Capacitor أو Android Native.
إذا كان المطلوب APK فأضف خطوات البناء النهائية.
`;
}
