import { FALLBACK_MODELS } from "./model-registry";

export function getNextModel(current?: string): string | null {
  if (!current) return FALLBACK_MODELS[0] || null;
  const index = FALLBACK_MODELS.indexOf(current);
  if (index === -1) return FALLBACK_MODELS[0] || null;
  return FALLBACK_MODELS[index + 1] || null;
}
