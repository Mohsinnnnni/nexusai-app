export type Attachment = {
  name: string;
  type?: string;
  dataUrl?: string;
  extractedText?: string;
};

export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  attachments?: Attachment[];
  citations?: string[];
  images?: string[];
};

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

function getUserApiKey(model?: string): string | undefined {
  if (!model) return undefined;
  const perModel = localStorage.getItem(`model-key-${model}`);
  if (perModel) return perModel;

  if (model.startsWith("openrouter/")) return localStorage.getItem("nexus-openrouter-key") || undefined;
  if (model.startsWith("openai-direct/")) return localStorage.getItem("nexus-openai-key") || undefined;
  if (model.startsWith("groq/")) return localStorage.getItem("nexus-groq-key") || undefined;
  if (model.startsWith("perplexity/")) return localStorage.getItem("nexus-perplexity-key") || undefined;
  return undefined;
}

export async function streamChat({
  messages,
  model,
  systemPrompt,
  mode,
  onDelta,
  onCitations,
  onImages,
  onDone,
  onError,
  signal,
}: {
  messages: ChatMessage[];
  model?: string;
  systemPrompt?: string;
  mode?: string;
  onDelta: (text: string) => void;
  onCitations?: (citations: string[]) => void;
  onImages?: (images: string[]) => void;
  onDone: () => void;
  onError: (error: string) => void;
  signal?: AbortSignal;
}) {
  try {
    const userApiKey = getUserApiKey(model);
    const trimmedMessages = messages.slice(-12).map((m) => ({
      role: m.role,
      content: m.content,
      attachments: m.attachments?.map((a) => ({
        name: a.name,
        type: a.type,
        dataUrl: a.dataUrl?.slice(0, 900000),
        extractedText: a.extractedText?.slice(0, 20000),
      })),
    }));

    const resp = await fetch(CHAT_URL, {
      method: "POST",
      cache: "no-store",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
      },
      body: JSON.stringify({
        messages: trimmedMessages,
        model,
        systemPrompt,
        mode,
        userApiKey,
      }),
      signal,
    });

    if (!resp.ok) {
      const data = await resp.json().catch(() => ({}));
      onError(data.error || `خطأ: ${resp.status}`);
      return;
    }

    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await resp.json();
      if (data.type === "image_generation") {
        if (data.text) onDelta(data.text);
        if (data.images?.length && onImages) onImages(data.images.filter(Boolean));
        onDone();
        return;
      }
      if (data.error) {
        onError(data.error);
        return;
      }
    }

    if (!resp.body) {
      onError("لا يوجد استجابة");
      return;
    }

    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let newlineIdx: number;
      while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
        let line = buffer.slice(0, newlineIdx);
        buffer = buffer.slice(newlineIdx + 1);
        if (line.endsWith("\r")) line = line.slice(0, -1);
        if (!line || line.startsWith(":")) continue;
        if (!line.startsWith("data: ")) continue;

        const jsonStr = line.slice(6).trim();
        if (jsonStr === "[DONE]") break;

        try {
          const parsed = JSON.parse(jsonStr);
          const content = parsed.choices?.[0]?.delta?.content ?? parsed.choices?.[0]?.message?.content;
          if (content) onDelta(content);
          if (Array.isArray(parsed.citations) && onCitations) onCitations(parsed.citations);
        } catch {
          // ignore malformed partial chunks
        }
      }
    }

    onDone();
  } catch (e: any) {
    if (e?.name === "AbortError") return;
    onError(e?.message || "خطأ في الاتصال");
  }
}
