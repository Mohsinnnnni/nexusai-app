import hadithDB from "./data/hadith-db.sample.json";

export type HadithEntry = {
  id: number;
  book: string;
  book_ar: string;
  chapter: string;
  text: string;
  grade: string;
};

export function searchHadith(query: string): HadithEntry[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return (hadithDB as HadithEntry[])
    .filter((h) =>
      h.text.toLowerCase().includes(q) ||
      h.book.toLowerCase().includes(q) ||
      h.book_ar.includes(query) ||
      h.chapter.toLowerCase().includes(q)
    )
    .slice(0, 10);
}
