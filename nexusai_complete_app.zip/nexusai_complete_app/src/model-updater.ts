import { DEFAULT_MODELS, type ModelItem } from "./model-registry";

const STORAGE_KEY = "nexus-models-v1";
const UPDATED_AT_KEY = "nexus-models-updated-at";

export function getCachedModels(): ModelItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_MODELS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length ? parsed : DEFAULT_MODELS;
  } catch {
    return DEFAULT_MODELS;
  }
}

export async function updateModels(force = false): Promise<ModelItem[]> {
  const lastUpdated = Number(localStorage.getItem(UPDATED_AT_KEY) || 0);
  const stale = Date.now() - lastUpdated > 24 * 60 * 60 * 1000;
  if (!force && !stale) return getCachedModels();

  try {
    const res = await fetch("https://openrouter.ai/api/v1/models", { cache: "no-store" });
    if (!res.ok) throw new Error(`OpenRouter models failed: ${res.status}`);
    const json = await res.json();
    const remote: ModelItem[] = (json.data || []).map((m: any) => ({
      name: m.name || m.id,
      id: `openrouter/${m.id}`,
      provider: "openrouter",
      category: m.id?.includes("image") ? "image" : "chat",
      supportsFiles: true,
    }));

    const merged = dedupeById([...DEFAULT_MODELS, ...remote]);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    localStorage.setItem(UPDATED_AT_KEY, String(Date.now()));
    return merged;
  } catch {
    return getCachedModels();
  }
}

function dedupeById(items: ModelItem[]): ModelItem[] {
  const map = new Map<string, ModelItem>();
  for (const item of items) map.set(item.id, item);
  return Array.from(map.values());
}
