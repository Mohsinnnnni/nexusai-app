export function devPrompt(prompt: string) {
  return `
أنت مهندس برمجيات خبير ومصمم حلول متكامل.
أنشئ مشروعاً كاملاً بناءً على الطلب التالي:
${prompt}

المطلوب في الرد:
1. تحليل المطلوب
2. بنية المشروع
3. كل الملفات المطلوبة
4. الكود الكامل داخل كتل منفصلة لكل ملف
5. خطوات التشغيل والبناء

إذا كان المطلوب موقعاً: استخدم React + Vite + Tailwind.
إذا كان المطلوب تطبيقاً: استخدم React + Capacitor أو Android Native حسب الطلب.
إذا كان المطلوب تحويل موقع إلى APK: أنشئ مشروع Android WebView كامل.
إذا كان المطلوب تحويل ZIP إلى APK: اشرح التحليل، ثم أنشئ build pipeline مناسب.
`;
}

export function websiteToAPK(url: string) {
  return `
أنشئ تطبيق Android WebView كامل لهذا الموقع:
${url}

المطلوب:
- AndroidManifest.xml
- MainActivity.kt
- إعدادات الإنترنت والـ WebView
- زر رجوع
- Splash Screen
- App icon
`;
}

export function zipToAPKPrompt() {
  return `
حلل المشروع المضغوط، حدد نوعه، ثم أنشئ خطة تحويل إلى APK.
إذا كان React/Vite أو Next، استخدم Capacitor.
إذا كان موقعاً ثابتاً، استخدم WebView.
إذا كان Flutter أو Android Native، أعد بناء الحزمة مباشرة.
`;
}
