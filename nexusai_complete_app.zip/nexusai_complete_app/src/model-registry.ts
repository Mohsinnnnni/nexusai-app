export type ModelItem = {
  name: string;
  id: string;
  provider: "openrouter" | "openai-direct" | "groq" | "perplexity" | "lovable";
  category?: "chat" | "code" | "image" | "search" | "free";
  supportsFiles?: boolean;
};

export const FALLBACK_MODELS: string[] = [
  "openrouter/openai/gpt-5-mini",
  "openrouter/google/gemini-2.5-flash",
  "openrouter/deepseek/deepseek-chat",
  "openrouter/moonshotai/kimi-k2",
  "openrouter/zhipuai/glm-4.5",
];

export const DEFAULT_MODELS: ModelItem[] = [
  { name: "GPT-5", id: "openrouter/openai/gpt-5", provider: "openrouter", category: "chat", supportsFiles: true },
  { name: "GPT-5 Mini", id: "openrouter/openai/gpt-5-mini", provider: "openrouter", category: "chat", supportsFiles: true },
  { name: "Claude 3.5 Sonnet", id: "openrouter/anthropic/claude-3.5-sonnet", provider: "openrouter", category: "code", supportsFiles: true },
  { name: "Gemini 2.5 Flash", id: "openrouter/google/gemini-2.5-flash", provider: "openrouter", category: "chat", supportsFiles: true },
  { name: "Gemini Flash Image", id: "openrouter/google/gemini-2.5-flash-image", provider: "openrouter", category: "image", supportsFiles: true },
  { name: "Perplexity Sonar", id: "perplexity/sonar", provider: "perplexity", category: "search" },
  { name: "DeepSeek Chat", id: "openrouter/deepseek/deepseek-chat", provider: "openrouter", category: "free", supportsFiles: true },
  { name: "Kimi K2", id: "openrouter/moonshotai/kimi-k2", provider: "openrouter", category: "free", supportsFiles: true },
  { name: "GLM 4.5", id: "openrouter/zhipuai/glm-4.5", provider: "openrouter", category: "free", supportsFiles: true },
  { name: "Qwen 2.5", id: "openrouter/qwen/qwen-2.5-7b-instruct", provider: "openrouter", category: "free", supportsFiles: true },
];
