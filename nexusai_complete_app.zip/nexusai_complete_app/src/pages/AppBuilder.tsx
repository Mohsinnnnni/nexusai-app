import { useMemo, useState } from "react";
import { buildProjectPrompt } from "../app-builder-engine";

export default function AppBuilder() {
  const [prompt, setPrompt] = useState("");
  const generated = useMemo(() => buildProjectPrompt(prompt), [prompt]);

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">AI App Builder</h1>
      <textarea
        className="w-full min-h-40 rounded-xl border p-4"
        placeholder="صف التطبيق الذي تريد بناءه كاملاً"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <div className="rounded-xl border p-4 bg-muted/20">
        <pre className="whitespace-pre-wrap text-sm">{generated}</pre>
      </div>
    </div>
  );
}
