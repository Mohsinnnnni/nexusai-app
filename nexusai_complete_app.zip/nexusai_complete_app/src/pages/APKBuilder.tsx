import { useMemo, useState } from "react";
import { apkPrompt } from "../apk-engine";

export default function APKBuilder() {
  const [prompt, setPrompt] = useState("");
  const generated = useMemo(() => apkPrompt(prompt), [prompt]);

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">APK Builder</h1>
      <textarea
        className="w-full min-h-40 rounded-xl border p-4"
        placeholder="اكتب وصف التطبيق الذي تريد إخراجه كـ APK"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <div className="rounded-xl border p-4 bg-muted/20">
        <pre className="whitespace-pre-wrap text-sm">{generated}</pre>
      </div>
    </div>
  );
}
