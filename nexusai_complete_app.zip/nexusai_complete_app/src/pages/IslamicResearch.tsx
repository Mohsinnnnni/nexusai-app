import { useMemo, useState } from "react";
import { searchHadith } from "../hadith-search";
import { islamicPrompt } from "../islamic-engine";

export default function IslamicResearch() {
  const [query, setQuery] = useState("");
  const results = useMemo(() => searchHadith(query), [query]);
  const enrichedPrompt = useMemo(() => islamicPrompt(query), [query]);

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">البحوث الإسلامية</h1>
      <textarea
        className="w-full min-h-32 rounded-xl border p-4"
        placeholder="اكتب سؤالك الشرعي أو الحديث الذي تريد البحث عنه"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <div className="rounded-xl border p-4 bg-muted/20">
        <p className="font-semibold mb-2">النص الذي يرسل للنموذج</p>
        <pre className="whitespace-pre-wrap text-sm">{enrichedPrompt}</pre>
      </div>

      <div className="space-y-3">
        {results.map((h) => (
          <div key={h.id} className="rounded-xl border p-4">
            <p className="font-medium">{h.text}</p>
            <p className="text-sm text-muted-foreground mt-2">{h.book_ar} — {h.chapter}</p>
            <p className="text-sm mt-1">الحكم: {h.grade}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
