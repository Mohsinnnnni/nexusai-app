import { useMemo, useState } from "react";
import { devPrompt } from "../dev-engine";

export default function AIDeveloper() {
  const [prompt, setPrompt] = useState("");
  const generated = useMemo(() => devPrompt(prompt), [prompt]);

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">AI Developer</h1>
      <textarea
        className="w-full min-h-40 rounded-xl border p-4"
        placeholder="اكتب وصف التطبيق أو الموقع أو المشروع الذي تريد بناءه"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <div className="rounded-xl border p-4 bg-muted/20">
        <pre className="whitespace-pre-wrap text-sm">{generated}</pre>
      </div>
    </div>
  );
}
