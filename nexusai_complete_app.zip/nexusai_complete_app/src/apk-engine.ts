export function apkPrompt(prompt: string) {
  return `
أنشئ مشروع Android APK كامل بناءً على الوصف التالي:
${prompt}

يجب أن يشمل:
- AndroidManifest.xml
- MainActivity
- الشاشات الأساسية
- الأيقونة واسم التطبيق
- خطوات البناء
- ملف ZIP للمشروع النهائي
`;
}
