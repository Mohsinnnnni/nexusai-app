import express from "express";
import { exec } from "child_process";
import fs from "fs";
import path from "path";

const app = express();
app.use(express.json({ limit: "20mb" }));

function run(cmd, cwd = process.cwd()) {
  return new Promise((resolve, reject) => {
    exec(cmd, { cwd }, (error, stdout, stderr) => {
      if (error) reject(new Error(stderr || stdout || String(error)));
      else resolve(stdout);
    });
  });
}

app.post("/api/build-apk", async (req, res) => {
  try {
    const projectDir = req.body?.projectDir || process.cwd();
    await run("npm install", projectDir);
    await run("npm run build", projectDir);
    await run("npx cap add android || true", projectDir);
    await run("npx cap copy", projectDir);
    await run("./gradlew assembleRelease", path.join(projectDir, "android"));

    const apkPath = path.join(projectDir, "android", "app", "build", "outputs", "apk", "release", "app-release.apk");
    if (!fs.existsSync(apkPath)) throw new Error("APK not found");

    res.json({ ok: true, download: apkPath });
  } catch (error) {
    res.status(500).json({ ok: false, error: error instanceof Error ? error.message : "Build failed" });
  }
});

app.listen(3001, () => {
  console.log("Build server running on http://localhost:3001");
});
