import { exec } from "child_process";

export function runCode(command, cwd = process.cwd()) {
  return new Promise((resolve, reject) => {
    exec(command, { cwd }, (error, stdout, stderr) => {
      if (error) return reject(stderr || stdout || String(error));
      resolve(stdout);
    });
  });
}

export async function execute(code, lang) {
  if (lang === "node") return runCode(`node -e ${JSON.stringify(code)}`);
  if (lang === "python") return runCode(`python3 -c ${JSON.stringify(code)}`);
  if (lang === "bash") return runCode(code);
  throw new Error("Unsupported language");
}
