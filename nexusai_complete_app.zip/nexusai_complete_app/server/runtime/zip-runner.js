import unzipper from "unzipper";
import fs from "fs";

export async function extractZip(zipPath, outputDir) {
  await fs.createReadStream(zipPath).pipe(unzipper.Extract({ path: outputDir })).promise();
  return outputDir;
}
