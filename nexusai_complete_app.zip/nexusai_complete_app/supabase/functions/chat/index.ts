import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const IMAGE_MODELS = [
  "openrouter/google/gemini-2.5-flash-image",
  "openrouter/google/gemini-3-pro-image-preview",
  "google/gemini-2.5-flash-image",
  "google/gemini-3-pro-image-preview",
];

const FALLBACK_MODELS = [
  "openrouter/openai/gpt-5-mini",
  "openrouter/google/gemini-2.5-flash",
  "openrouter/deepseek/deepseek-chat",
  "openrouter/moonshotai/kimi-k2",
  "openrouter/zhipuai/glm-4.5",
];

const ISLAMIC_SOURCES_PROMPT = `
اعتمد في الإجابة الشرعية على مصادر السلف والقرون الأولى أولاً.
الأولوية لـ: صحيح البخاري، صحيح مسلم، سنن أبي داود، سنن الترمذي، سنن النسائي الكبرى، سنن النسائي الصغرى، سنن ابن ماجه، سنن الدارمي، موطأ الإمام مالك، مسند أحمد، مصنف ابن أبي شيبة، السنة للخلال، السنة للأثرم، السنة لعبدالله بن الإمام أحمد، مسائل صالح، مسائل ابن هانئ، كتب الإمام أحمد، كتب البربهاري، كتب ابن بطة، كتب أبي عبيد، كتب الدارمي، كتب ابن أبي حاتم.
اذكر المصدر بوضوح وقدم فهم السلف.
`;

function getLovableGatewayConfig(fallbackModel?: string) {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");
  return {
    url: "https://ai.gateway.lovable.dev/v1/chat/completions",
    apiKey,
    model: fallbackModel || "google/gemini-3-flash-preview",
    provider: "lovable",
  };
}

function normalizeModel(model: string) {
  return model.replace(/^(openrouter|openai-direct|groq|perplexity)\//, "");
}

function getModelSpecificEnvKey(model: string) {
  return `MODEL_KEY_${model.replace(/[\/-\.]/g, "_").toUpperCase()}`;
}

function getProviderConfig(model: string, userApiKey?: string) {
  const modelKey = Deno.env.get(getModelSpecificEnvKey(model));
  const resolvedApiKey = userApiKey || modelKey;

  if (model.startsWith("groq/")) {
    const apiKey = resolvedApiKey || Deno.env.get("GROQ_API_KEY");
    if (!apiKey) return null;
    return { url: "https://api.groq.com/openai/v1/chat/completions", apiKey, model: normalizeModel(model), provider: "groq" };
  }

  if (model.startsWith("perplexity/")) {
    const apiKey = resolvedApiKey || Deno.env.get("PERPLEXITY_API_KEY");
    if (!apiKey) return null;
    return { url: "https://api.perplexity.ai/chat/completions", apiKey, model: normalizeModel(model), provider: "perplexity" };
  }

  if (model.startsWith("openrouter/") || !model || model.includes("/")) {
    const apiKey = resolvedApiKey || Deno.env.get("OPENROUTER_API_KEY");
    if (!apiKey) return null;
    return {
      url: "https://openrouter.ai/api/v1/chat/completions",
      apiKey,
      model: model.startsWith("openrouter/") ? model.replace("openrouter/", "") : model,
      provider: "openrouter",
    };
  }

  if (model.startsWith("openai-direct/")) {
    const apiKey = resolvedApiKey || Deno.env.get("OPENAI_API_KEY");
    if (!apiKey) return null;
    return { url: "https://api.openai.com/v1/chat/completions", apiKey, model: normalizeModel(model), provider: "openai-direct" };
  }

  return { ...getLovableGatewayConfig(model || undefined) };
}

function buildMessages(messages: any[], systemPrompt?: string, mode?: string) {
  const defaultSystemPrompt = `You are NexusAI, an expert AI assistant for coding, research, files, and productivity. Match the user's language. Give direct, high-value answers. Use markdown when helpful.`;
  const combinedSystemPrompt = [defaultSystemPrompt, mode === "islamic" ? ISLAMIC_SOURCES_PROMPT : "", systemPrompt || ""].filter(Boolean).join("\n\n");

  const apiMessages: any[] = [{ role: "system", content: combinedSystemPrompt }];

  for (const msg of messages) {
    if (msg.role === "user" && msg.attachments?.length > 0) {
      const content: any[] = [];
      if (msg.content) content.push({ type: "text", text: msg.content });
      for (const att of msg.attachments) {
        if (att.type?.startsWith("image/") && att.dataUrl) {
          content.push({ type: "image_url", image_url: { url: att.dataUrl.slice(0, 900000), detail: "high" } });
        } else if (att.extractedText) {
          content.push({ type: "text", text: `\n[Attached file: ${att.name}]\n${String(att.extractedText).slice(0, 20000)}` });
        }
      }
      apiMessages.push({ role: "user", content });
    } else {
      apiMessages.push({ role: msg.role, content: msg.content });
    }
  }

  return apiMessages.slice(-13);
}

async function callProvider(url: string, apiKey: string, model: string, apiMessages: any[], extraHeaders?: Record<string, string>, extraBody?: Record<string, any>) {
  return await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      Accept: "text/event-stream, application/json",
      "Cache-Control": "no-cache",
      ...(extraHeaders || {}),
    },
    body: JSON.stringify({ model, messages: apiMessages, stream: true, ...extraBody }),
  });
}

async function handleImageGeneration(apiMessages: any[], model: string) {
  const config = getProviderConfig(model) || getLovableGatewayConfig(model);
  const response = await fetch(config.url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ model: config.model, messages: apiMessages, modalities: ["image", "text"] }),
  });

  if (!response.ok) {
    const t = await response.text();
    return new Response(JSON.stringify({ error: `Image generation failed: ${t}` }), { status: response.status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const data = await response.json();
  const message = data.choices?.[0]?.message;
  const text = message?.content || "";
  const images = message?.images || [];

  return new Response(JSON.stringify({ type: "image_generation", text, images: images.map((img: any) => img.image_url?.url || img.url || "") }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, model, systemPrompt, mode, userApiKey } = await req.json();
    const apiMessages = buildMessages(messages, systemPrompt, mode);

    if (model && IMAGE_MODELS.includes(model)) {
      return await handleImageGeneration(apiMessages, model);
    }

    let currentModel = model || FALLBACK_MODELS[0];
    let tried = 0;

    while (currentModel && tried < 8) {
      tried += 1;
      const provider = getProviderConfig(currentModel, userApiKey);
      if (!provider) {
        currentModel = FALLBACK_MODELS[tried - 1] || null;
        continue;
      }

      const extraHeaders = provider.provider === "openrouter"
        ? { "HTTP-Referer": "https://nexusai.app", "X-Title": "NexusAI" }
        : undefined;

      const response = await callProvider(provider.url, provider.apiKey, provider.model, apiMessages, extraHeaders);

      if (response.ok) {
        return new Response(response.body, {
          headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
        });
      }

      const errorText = await response.text();
      console.error(`${provider.provider} error (${response.status}):`, errorText);

      if (response.status === 429) {
        currentModel = FALLBACK_MODELS[tried - 1] || null;
        continue;
      }

      if ([401, 402, 403].includes(response.status) || response.status >= 500) {
        currentModel = FALLBACK_MODELS[tried - 1] || null;
        continue;
      }

      return new Response(JSON.stringify({ error: `Provider error (${response.status}): ${errorText}` }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const fallback = getLovableGatewayConfig();
    const fallbackResp = await callProvider(fallback.url, fallback.apiKey, fallback.model, apiMessages);
    if (!fallbackResp.ok) {
      const ft = await fallbackResp.text();
      return new Response(JSON.stringify({ error: `All providers failed. Last error: ${ft}` }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(fallbackResp.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
